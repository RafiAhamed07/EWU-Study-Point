"""A* search for a directed, weighted graph.

The graph, node coordinates, start node, and goal node are read from input.txt.
The Euclidean distance from a node to the goal is used as the heuristic.
"""

from __future__ import annotations

from dataclasses import dataclass
from heapq import heappop, heappush
from itertools import count
from math import hypot
from pathlib import Path
from typing import Dict, List, Optional, Tuple


Coordinates = Dict[str, Tuple[float, float]]
AdjacencyList = Dict[str, List[Tuple[str, float]]]


@dataclass
class NodeState:
    """The information A* keeps for one possible route to a node."""

    node_id: str
    parent: Optional["NodeState"]
    g: float
    f: float


def _display_number(value: float) -> str:
    """Print whole-number costs without an unnecessary .0."""

    return str(int(value)) if value.is_integer() else f"{value:g}"


def _parse_node_line(line: str) -> Tuple[str, float, float]:
    parts = line.replace(",", " ").split()
    if len(parts) == 3:
        node_id, x_text, y_text = parts
        return node_id, float(x_text), float(y_text)

    # Also accepts the compact one-character sample form, such as S60.
    compact = line.strip()
    if len(compact) >= 3 and compact[-2:].isdigit():
        return compact[:-2], float(compact[-2]), float(compact[-1])

    raise ValueError(
        f"Invalid node line {line!r}. Use: node_id x_coordinate y_coordinate"
    )


def _parse_edge_line(
    line: str, known_nodes: Coordinates
) -> Tuple[str, str, float]:
    parts = line.split()
    if len(parts) == 3:
        source, destination, cost_text = parts
        return source, destination, float(cost_text)

    # Also accepts compact sample edges, such as SA1. Known node IDs are used
    # so multi-character node names are handled whenever the split is unique.
    compact = line.strip()
    candidates: List[Tuple[str, str, float]] = []
    nodes = sorted(known_nodes, key=len, reverse=True)
    for source in nodes:
        if not compact.startswith(source):
            continue
        remainder = compact[len(source) :]
        for destination in nodes:
            if not remainder.startswith(destination):
                continue
            cost_text = remainder[len(destination) :]
            try:
                cost = float(cost_text)
            except ValueError:
                continue
            candidates.append((source, destination, cost))

    if len(candidates) == 1:
        return candidates[0]

    raise ValueError(
        f"Invalid or ambiguous edge line {line!r}. Use: source destination cost"
    )


def read_graph(
    input_path: str | Path = "input.txt",
) -> Tuple[Coordinates, AdjacencyList, str, str]:
    """Read one problem instance using the format given in the assignment."""

    path = Path(input_path)
    if not path.exists():
        raise FileNotFoundError(
            f"Could not find {path}. Keep input.txt in the same folder as the code."
        )

    lines = [line.strip() for line in path.read_text(encoding="utf-8").splitlines()]
    lines = [line for line in lines if line and not line.startswith("#")]
    position = 0

    def take_line(description: str) -> str:
        nonlocal position
        if position >= len(lines):
            raise ValueError(f"Missing {description} in {path.name}.")
        value = lines[position]
        position += 1
        return value

    vertex_count = int(take_line("number of vertices"))
    if vertex_count <= 0:
        raise ValueError("The number of vertices must be positive.")

    coords: Coordinates = {}
    for _ in range(vertex_count):
        node_id, x, y = _parse_node_line(take_line("vertex information"))
        if node_id in coords:
            raise ValueError(f"Duplicate node ID: {node_id}")
        coords[node_id] = (x, y)

    edge_count = int(take_line("number of edges"))
    if edge_count < 0:
        raise ValueError("The number of edges cannot be negative.")

    adjlist: AdjacencyList = {node_id: [] for node_id in coords}
    for _ in range(edge_count):
        source, destination, cost = _parse_edge_line(
            take_line("edge information"), coords
        )
        if source not in coords or destination not in coords:
            raise ValueError(f"Unknown node in edge: {source} -> {destination}")
        if cost < 0:
            raise ValueError("A* search requires non-negative edge costs.")
        adjlist[source].append((destination, cost))

    start = take_line("start node")
    goal = take_line("goal node")
    if start not in coords:
        raise ValueError(f"Unknown start node: {start}")
    if goal not in coords:
        raise ValueError(f"Unknown goal node: {goal}")
    if position != len(lines):
        raise ValueError(f"Unexpected extra input after the goal node in {path.name}.")

    return coords, adjlist, start, goal


def heuristic(node_id: str, goal_id: str, coords: Coordinates) -> float:
    """Return the Euclidean distance from node_id to goal_id."""

    x1, y1 = coords[node_id]
    x2, y2 = coords[goal_id]
    return hypot(x1 - x2, y1 - y2)


def reconstruct_path(goal_state: NodeState) -> List[str]:
    """Backtrack through parent states to construct the solution path."""

    path: List[str] = []
    state: Optional[NodeState] = goal_state
    while state is not None:
        path.append(state.node_id)
        state = state.parent
    path.reverse()
    return path


def a_star_search(
    coords: Coordinates,
    adjlist: AdjacencyList,
    start: str,
    goal: str,
) -> Optional[Tuple[List[str], float]]:
    """Find a minimum-cost path from start to goal with A* search."""

    tie_breaker = count()
    min_queue: List[Tuple[float, int, NodeState]] = []

    start_g = 0.0
    start_f = start_g + heuristic(start, goal, coords)
    start_state = NodeState(start, None, start_g, start_f)
    heappush(min_queue, (start_state.f, next(tie_breaker), start_state))

    # best_g prevents cycles and avoids expanding a worse route to the same node.
    best_g: Dict[str, float] = {start: 0.0}

    while min_queue:
        _, _, current = heappop(min_queue)

        if current.g > best_g.get(current.node_id, float("inf")):
            continue

        if current.node_id == goal:
            return reconstruct_path(current), current.g

        for neighbor, edge_cost in adjlist[current.node_id]:
            new_g = current.g + edge_cost
            if new_g >= best_g.get(neighbor, float("inf")):
                continue

            best_g[neighbor] = new_g
            new_f = new_g + heuristic(neighbor, goal, coords)
            new_state = NodeState(neighbor, current, new_g, new_f)
            heappush(min_queue, (new_state.f, next(tie_breaker), new_state))

    return None


def solve(input_path: str | Path = "input.txt") -> None:
    """Read the graph, run A*, and print the answer in the required format."""

    coords, adjlist, start, goal = read_graph(input_path)
    result = a_star_search(coords, adjlist, start, goal)

    if result is None:
        print("No solution path found")
        return

    path, cost = result
    print("Solution path " + " - ".join(path))
    print("Solution cost " + _display_number(cost))


if __name__ == "__main__":
    solve()
