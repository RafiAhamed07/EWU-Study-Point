"""Run this file in VS Code to solve the graph stored in input.txt."""

from pathlib import Path

from a_star_search import solve


if __name__ == "__main__":
    solve(Path(__file__).with_name("input.txt"))
