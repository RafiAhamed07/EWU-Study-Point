# Offline 01 - A* Search

This folder is ready to open and run in Visual Studio Code. It implements A*
search on a directed, weighted graph and uses Euclidean distance to the goal as
the heuristic.

## Easiest way to run

1. Extract the downloaded ZIP file.
2. Open the `Astar_Search_VSCode` folder in VS Code.
3. Make sure the Microsoft Python extension is installed in VS Code.
4. Open `main.py` and click **Run Python File**, or run:

   ```bash
   python main.py
   ```

No third-party package is required.

Expected output for the included `input.txt`:

```text
Solution path S - C - G
Solution cost 6
```

## Required notebook submission

Open `Offline01_Astar_Search.ipynb` in VS Code and click **Run All**. It reads
the same `input.txt` file. Submit this `.ipynb` file if your instructor requires
the notebook format.

## Test the second sample

Replace the contents of `input.txt` with the contents of `sample2_input.txt`,
then run the program again. The result should be:

```text
Solution path S - A - G
Solution cost 2
```

## Input format

```text
V
node_id x y        (repeat V times)
E
source destination cost   (repeat E times)
start_node
goal_node
```

Keep `input.txt` in the same folder as `main.py` and the notebook. Node and edge
values should normally be separated by spaces. The compact single-character
sample style (`S60`, `SA1`) is also accepted.

## Files

- `Offline01_Astar_Search.ipynb`: complete assignment notebook for submission
- `main.py`: easiest entry point for VS Code
- `a_star_search.py`: reusable implementation
- `input.txt`: first sample input
- `sample2_input.txt`: second sample input
- `README.md`: usage instructions

Time complexity is `O((V + E) log V)` with the priority queue, and auxiliary
space complexity is `O(V + E)` for the graph, best costs, and queued states.
